import * as React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import { Typography } from '@mui/material';

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Allcard() {
  return (
      
    <Box sx={{ width: '100%' }}>
      <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }} >
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/Ha59c8369985e4332ab6aff1429ae5a03A.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Kids Car
              </Typography>

              <Typography>
                  Price: $3.40 
              </Typography>
          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/Ue5648d1593fa452dbfce32e67d20dda01.jpg" height='100px' alt="" />
          <Typography style={{fontWeight:'bold'}}>
              Shalwar kameez
          </Typography>

          <Typography>
              Price:$4.50
          </Typography>
          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/H18ac81761df74449949a111a4a3f2313T.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Kitchen Sets
              </Typography>

              <Typography>
                  Price: $4.50
              </Typography>
          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/H0edb9c2638c641878593c0009e89e9caP.jpg_220x220.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  I-PAD
              </Typography>

              <Typography>
                  price:$3.00
              </Typography>
          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/Hb90cab1301a14436a84fb7c173c0aa6cv.jpg_220x220.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Digital Led Watch
              </Typography>

              <Typography>
                  Price:$3.50
              </Typography>
          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/HTB10a8NMkPoK1RjSZKb7601IXXab.png_220x220.png" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Electronic vape
              </Typography>

              <Typography>
                  Price:$5.70
              </Typography>
          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>

              <img src="https://s.alicdn.com/@sc04/kf/Hf81aa45984a2487f8afc7ce760d8fd45c.jpg_220x220.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Bike Helmet
              </Typography>

              <Typography>
                  Price: $5.70
              </Typography>

          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>

              <img src="https://s.alicdn.com/@sc04/kf/HTB1pV8XcEKF3KVjSZFEq6xExFXaL.jpg_220x220.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Trouser & Shirt
              </Typography>

              <Typography>
                  Price: $3.20
              </Typography>


          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/H5bde7fe4e9dd4dba871ffe03f8dbf410R.jpg_220x220.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Drone
              </Typography>

              <Typography>
                  Price:$20.00
              </Typography>
          </Item>
        </Grid>
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/HTB1wzWwJCrqK1RjSZK9q6xyypXaB.jpg_220x220.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  TV Receiver
              </Typography>

              <Typography>
                  Price:$4.5
              </Typography>


          </Item>
        </Grid>

        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/Hc3cafec11c6e4762ba0758d4cccec6013.jpg_220x220.jpg" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Rain Coat
              </Typography>

              <Typography>
                  Price:$3.5
              </Typography>


          </Item>
        </Grid>
        
        <Grid item xs={2}>
          <Item>
              <img src="https://s.alicdn.com/@sc04/kf/H45beb557ef4547f6af8f0a37212b8ef1D.png" height='100px' alt="" />

              <Typography style={{fontWeight:'bold'}}>
                  Fry Pen
              </Typography>

              <Typography>
                  Price:$50.00
              </Typography>


          </Item>
        </Grid>
        
        

      </Grid>
    </Box>
  );
}










































// import * as React from 'react';
// import ImageList from '@mui/material/ImageList';
// import ImageListItem from '@mui/material/ImageListItem';
// import ImageListItemBar from '@mui/material/ImageListItemBar';
// import ListSubheader from '@mui/material/ListSubheader';
// import IconButton from '@mui/material/IconButton';
// import InfoIcon from '@mui/icons-material/Info';
// import { Typography } from '@mui/material';
// import { width } from '@mui/system';

// export default function Allcard() {
//   return (
//     <Typography sx={{ width: 1200, height: 50,px:18 }} >
//             {itemData.map((item) => (
//         <ImageListItem key={item.img} sx={{px:5}}>
//           <img
//             src={`${item.img}?w=248&fit=crop&auto=format`}
//             srcSet={`${item.img}?w=248&fit=crop&auto=format&dpr=2 2x`}
//             alt={item.title}
//             loading="lazy"
//           />
//           <ImageListItemBar
//             title={item.title}
//             subtitle={item.author}
//             actionIcon={
//               <IconButton
//                 sx={{ color: 'rgba(255, 255, 255, 0.54)' }}
//                 aria-label={`info about ${item.title}`}
//               >
//                 <InfoIcon />
//               </IconButton>
//             }
//           />
//         </ImageListItem>
//       ))}
//     </Typography>
//   );
// }

// const itemData = [
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/H0edb9c2638c641878593c0009e89e9caP.jpg_220x220.jpg',
//     title: 'I-PAD',
//     author: '$7.60',
//     rows: 2,
//     cols: 2,
//     featured: true,
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/HTB12l7JKrrpK1RjSZTEq6AWAVXau.jpg_220x220.jpg',
//     title: 'Towels',
//     author: '$2.40',
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/Hb77b1c9e236041949ed8c909cf0f578dL.jpg_220x220.jpg',
//     title: 'New Energy Vechicle Part',
//     author: '$3.50',
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/Hb90cab1301a14436a84fb7c173c0aa6cv.jpg_220x220.jpg',
//     title: 'LED Digital Watch',
//     author: '$5.40',
//     cols: 2,
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/HTB10a8NMkPoK1RjSZKb7601IXXab.png_220x220.png',
//     title: 'Electronic Vape',
//     author: '$5.30',
//     cols: 2,
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/HTB1wzWwJCrqK1RjSZK9q6xyypXaB.jpg_220x220.jpg',
//     title: 'TV Receivers',
//     author: '$2.00',
//     rows: 2,
//     cols: 2,
//     featured: true,
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/Hf81aa45984a2487f8afc7ce760d8fd45c.jpg_220x220.jpg',
//     title: 'Bike Helmet',
//     author: '$5.00',
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/H70d057c6333b4c21977053de02286461u.jpg_220x220.jpg',
//     title: 'Machine',
//     author: '$10.00',
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/Hc3cafec11c6e4762ba0758d4cccec6013.jpg_220x220.jpg',
//     title: 'Rain Coat',
//     author: '$2.00',
//     rows: 2,
//     cols: 2,
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/HTB1pV8XcEKF3KVjSZFEq6xExFXaL.jpg_220x220.jpg',
//     title: 'Men Trouser & shirt',
//     author: '@shelleypauls',
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/H5bde7fe4e9dd4dba871ffe03f8dbf410R.jpg_220x220.jpg',
//     title: 'Drone',
//     author: '$50.00',
//   },
//   {
//     img: 'https://s.alicdn.com/@sc04/kf/H4d252f2f1bb146bb8ba2f19d0599268de.jpg_220x220.jpg',
//     title: 'New LED Watch',
//     author: '$3.63',
//     cols: 2,
//   },
// ];
