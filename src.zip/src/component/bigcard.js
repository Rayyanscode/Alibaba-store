import * as React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import { Typography } from '@mui/material';

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Bigcard() {
  return (
    <Box sx={{ width: '100%' }}>
      <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }} style={{border:'2px solid black',marginBottom:'50px',height:'450px',width:'1500px',marginLeft:'4px',marginTop:'20px'}}>
        <Grid item xs={3}>
          <Item >
              <img src="https://www.pngplay.com/wp-content/uploads/4/Leather-Jacket-PNG-Clipart-Background.png" 
              width='342px' height='410px' alt="" />
          </Item>
        </Grid>
        <Grid item xs={3}>
            <Item>
          <Typography style={{fontWeight:'bold'}}>
              PREMIUM OEM FACTORIES
          </Typography>
          <Typography>
              Well-made clothing  with trendy  designs.
          </Typography>
          <img src="https://s.alicdn.com/@sc04/kf/H7cf6dd41cba849ab882c54e7f0530e56D.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3}>
          <Item>

              <Typography style={{fontWeight:'bold'}}>
                  Top Sales
              </Typography>

              <Typography>
                 Garments & Processing  Accessories
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/H1af5b1a5945548d5aab7c04dcb2f19377.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />

          </Item>
        </Grid>
        <Grid item xs={3}>
          <Item>4
              <Typography style={{fontWeight:'bold'}}>
                 Wedding Apparel & Accessories
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/H2d8a5253875b448c931478927406c4dfq.jpg_220x220.jpg" height='84px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3} style={{marginLeft:'374px',marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Delivered Duty Paid (DDP)
              </Typography>

              <Typography>
                  Include Shipping And Duty Fees
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/Hd0e58791ea3e4c29bfe1562359924be8B.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />


          </Item>
        </Grid>
        <Grid item xs={3} style={{marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Men's Clothing 
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/HTB1TD8mXK6sK1RjSsrbq6xbDXXa5.jpg_220x220.jpg" height='105px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3} style={{marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Sports Wear
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/Hcc98420451124afc817c74455ac5ed43n.jpg_220x220.jpg" height='105px' alt="" style={{marginLeft:'200px'}} />

          </Item>
        </Grid>
      </Grid>
    </Box>
  );
}
