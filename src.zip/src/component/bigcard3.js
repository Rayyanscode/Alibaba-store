import * as React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import { Typography } from '@mui/material';

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Bigcard3() {
  return (
    <Box sx={{ width: '100%' }}>
      <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }} style={{border:'2px solid black',marginBottom:'50px',height:'450px',width:'1500px',marginLeft:'4px',marginTop:'20px'}}>
        <Grid item xs={3}>
          <Item >
              <img src="https://s3.eu-central-1.amazonaws.com/apolloproducts/alpha/images/bannerTyre.png" 
              width='340px' height='410px' alt="" />
          </Item>
        </Grid>
        <Grid item xs={3}>
            <Item>
          <Typography style={{fontWeight:'bold'}}>
              PREMIUM OEM FACTORIES
          </Typography>
          <Typography>
              One-Stop services FOR Your Store.
          </Typography>
          <img src="https://s.alicdn.com/@sc04/kf/H02b772d0d2e849d783881908e35a79a7u.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3}>
          <Item>

              <Typography style={{fontWeight:'bold'}}>
                  Top Sales
              </Typography>

              <Typography>
                  Recovery & Off Road Accessories
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/HTB1jHXsh8jTBKNjSZFuq6z0HFXaN.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />

          </Item>
        </Grid>
        <Grid item xs={3}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Automative parts & Accessories
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/HTB1Zp2cg2DH8KJjy1Xcq6ApdXXaR.jpg_220x220.jpg" height='84px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3} style={{marginLeft:'374px',marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Delivered Duty Paid (DDP)
              </Typography>

              <Typography>
                  Include Shipping And Duty Fees
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/Hf6c7188cbc4040e3977e59ea5aa8fcf73.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />


          </Item>
        </Grid>
        <Grid item xs={3} style={{marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Recovrey & Off Road Accessories  
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/H79154a7817064dd4b611a68808c6948co.jpg_220x220.jpg" height='105px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3} style={{marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Wheels,Tires And Accessories
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/HLB1EO4eSCzqK1RjSZFpq6ykSXXa4.jpg_220x220.jpg" height='105px' alt="" style={{marginLeft:'200px'}} />

          </Item>
        </Grid>
      </Grid>
    </Box>
  );
}
