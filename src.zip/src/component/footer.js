import React from "react";

function Foo() {
    return(

        <div style={{marginTop:'50px',backgroundColor:'darkgrey',bottom:'fixed'}}>
            <div>
                <p style={{textAlign:'center'}}>Trade Alert - Delivering the latest product trends and industry news straight to your inbox.</p>
            </div>
            <div style={{marginLeft:'530px'}}>
                <input type="text" size='40' placeholder='YourEmail' /><button>Subscribe</button>
                <p>We’ll never share your email address with a third-party.</p>
            </div>
            <div style={{display:'flex',marginLeft:'250px'}}>
                <ol style={{listStyle:'none'}}>
                    <li>Customer Services</li>
                    <li>Help Center</li>
                    <li>Contact Us</li>
                    <li>Report Abuse</li>
                    <li>Submit a Dispute</li>
                </ol>
                <ol style={{listStyle:'none'}}>
                    <li>About Us</li>
                    <li>About Alibaba.com</li>
                    <li>About Alibaba Group</li>
                    <li>Sitemap</li>
                </ol>
                <ol style={{listStyle:'none'}}>
                    <li>Source on Alibaba.com</li>
                    <li>Resources</li>
                    <li>All Categories</li>
                    <li>Request for Quotation</li>
                    <li>Ready to Ship</li>
                </ol>
                <ol style={{listStyle:'none'}}>
                    <li>Source on Alibaba.com</li>
                    <li>Supplier Memberships</li>
                    <li>Learning Center</li>
                    <li>Partner Program</li>
                </ol>
                <ol style={{listStyle:'none'}}>
                    <li>Trade Services</li>
                    <li>Business Identity</li>
                    <li>Logistics Service</li>
                    <li>Letter of Credit</li>
                </ol>
            </div>
            <hr style={{color:'red'}} />
            <div style={{display:'flex',marginLeft:'150px'}}>
                <p>Download:</p>
                <img style={{marginLeft:'10px'}} src="https://upload.wikimedia.org/wikipedia/commons/1/11/Available_on_the_App_Store_%28gray%29.png" width='100px' height='40px' alt="" />
                <img style={{marginLeft:'10px'}} src="https://i.gadgets360cdn.com/large/Google_play_small_1556370716547.jpg" height='40px' width='100px' alt="" />
                <p style={{marginLeft:'150px'}}>Alibaba Supplier App :</p>
                <p style={{marginLeft:'200px'}}>Follow us:</p>
                <img src="https://cdn3.iconfinder.com/data/icons/picons-social/57/46-facebook-512.png" height='40px' alt="" />
                <img src="https://image.similarpng.com/very-thumbnail/2020/07/Instagram-black-and-white-logo-vector-png-(5).png" height='40px' alt="" />
                <img src="https://toppng.com/uploads/preview/free-round-youtube-icon-vector-logo-11553541445tohp89dd6v.png" height='40px' alt="" />
                </div>

        </div>

    )
    
}

export default Foo;