import * as React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import { Typography } from '@mui/material';

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Bigcard2() {
  return (
    <Box sx={{ width: '100%' }}>
      <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }} style={{border:'2px solid black',marginBottom:'50px',height:'450px',width:'1500px',marginLeft:'4px',marginTop:'20px'}}>
        <Grid item xs={3}>
          <Item >
              <img src="https://www.fonesquare.pk/wp-content/uploads/2021/03/Mpow-Flame-S-Bluetooth-Sports-Handsfree.png" 
              width='250px' height='410px' alt="" />
          </Item>
        </Grid>
        <Grid item xs={3}>
            <Item>
          <Typography style={{fontWeight:'bold'}}>
              PREMIUM OEM FACTORIES
          </Typography>
          <Typography>
              Customization Service Available
          </Typography>
          <img src="https://s.alicdn.com/@sc04/kf/H9c6b46a6372f464aa772a501e8982999x.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3}>
          <Item>

              <Typography style={{fontWeight:'bold'}}>
                  Top Sales
              </Typography>

              <Typography>
                  Home Audio,Video & Accessories
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/HTB1Y46HKkCWBuNjy0Faq6xUlXXaw.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />

          </Item>
        </Grid>
        <Grid item xs={3}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Speakers And Accessories
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/HTB1yATJaoLrK1Rjy0Fjq6zYXFXav.jpg_220x220.jpg" height='105px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3} style={{marginLeft:'374px',marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Delivered Duty Paid (DDP)
              </Typography>

              <Typography>
                  Include Shipping And Duty Fees
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/Ha894dab9b3964edca495c88b9a60e750k.jpg_220x220.jpg" height='80px' alt="" style={{marginLeft:'200px'}} />


          </Item>
        </Grid>
        <Grid item xs={3} style={{marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Camera Photo & Accessories  
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/H5bde7fe4e9dd4dba871ffe03f8dbf410R.jpg_220x220.jpg" height='105px' alt="" style={{marginLeft:'200px'}} />
          </Item>
        </Grid>
        <Grid item xs={3} style={{marginTop:'-250px'}}>
          <Item>
              <Typography style={{fontWeight:'bold'}}>
                  Presentation Equipment
              </Typography>

              <img src="https://s.alicdn.com/@sc04/kf/H6dd8fb15d5474cf99bb726c449768f873.jpg_220x220.jpg" height='105px' alt="" style={{marginLeft:'200px'}} />

          </Item>
        </Grid>
      </Grid>
    </Box>
  );
}
