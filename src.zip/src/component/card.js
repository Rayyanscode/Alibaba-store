import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { Typography } from '@mui/material';

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function ColumnsGrid(props) {
  return (
    <Box sx={{ flexGrow: 1, margin:3, marginTop:7 }}>
      <Grid container spacing={2} columns={6} style={{border:'2px solid lightGrey',borderRadius:'12px', backgroundColor:'darkwhite' ,  padding:'5px',height:'270px'}}>
        <Grid item xs={3} style={{padding:'0px'}}>
          <Typography style={{fontWeight:'Bold'}}>
            {props.title} 
            </Typography>
          <Item style={{backgroundColor:'lightGrey',marginTop:'10px',marginRight:'10px'}}>
            <img height='120px' width='80px' src={props.firstimage} alt="" />
          </Item>
          <Typography sx={{marginTop:'10px',marginLeft:'30px'}}>
            {props.all}
            <br />
            {props.dis}
          </Typography>
        </Grid>
        <Grid item xs={3} style={{padding:'0px'}}>
          <Item style={{backgroundColor:'lightGrey',marginTop:'35px'}}>
            <img height='120px' width='80px' src={props.secondimage} alt="" />

          </Item>
          <Typography sx={{marginTop:'10px',marginLeft:'30px'}}>
            {props.all1}
            <br />
            {props.dis1}
            </Typography>
        </Grid>
      </Grid>
    </Box>
  );
}
