import logo from './logo.svg';
import './App.css';
import Nav from './component/navbar';
import Belownav from './component/belownavbar';
import OutlinedCard from './component/slider';
import ColumnsGrid from './component/card';
import RowAndColumnSpacing from './component/cardgroup';
import Bigcard from './component/bigcard';
import Bigcard2 from './component/bigcard2';
import Bigcard3 from './component/bigcard3';
import Allcard from './component/allcard';
import 'bootstrap/dist/css/bootstrap.min.css';
import Foo from './component/footer';
function App() {
  return (
    <div>
  <Nav />


  <Belownav />

  <OutlinedCard />

<div style={{display:'flex'}}>

  <ColumnsGrid all="$1.29" dis="Best Digital Watch" title="New Arrival" firstimage="https://pngfile.net/public/uploads/preview/women-smart-watch-bluetooth-png-11589321664gmwdpgg7tn.png" 
  all1="$2.40" dis1=' Best iphone Earport' secondimage="https://vmart.pk/wp-content/uploads/2019/11/Apple-Airpods-Pro-In-Box.jpg"/>

  <ColumnsGrid all="$3.94" dis='iphone 12 pro max' title="Top Ranked Product" firstimage="https://png.pngitem.com/pimgs/s/530-5302712_element-case-iphone-11-pro-max-illusion-black.png" 
   all1="$3.84" dis1='Best Quality IPAD  ' secondimage="https://www.pngplay.com/wp-content/uploads/13/iPad-Transparent-Images.png"/>

  <ColumnsGrid all="$2.29" dis='Oppo A53' title="Personal Protective Equipment" firstimage="https://www.kindpng.com/picc/m/490-4903701_oppo-mobile-png-transparent-png.png"
 all1="$3.85" dis1='Branded Watch' secondimage="https://www.nicepng.com/png/detail/15-154351_watches-png-image-watch-png-for-picsart.png" />

  
  </div>

  <div style={{display:'flex',marginTop:'-15px'}}>

  <ColumnsGrid all="$1.29" dis="Samsung note 20" title="Dropshipping" firstimage="https://png.pngtree.com/png-clipart/20200813/ourlarge/pngtree-samsung-galaxy-note-20-png-image_2325162.jpg" 
  all1="$1.40" dis1=" Best Headphone" secondimage="https://p.kindpng.com/picc/s/1-19916_gamer-headset-png-transparent-png.png"/>

  <ColumnsGrid all="$3.94" dis='Best Design Watch' title="Global original sources" firstimage="https://snipstock.com/assets/cdn/png/060df88e695033d2b6da8016f7a2416c.png" 
   all1="$5.84" dis1=' Best Quality shirt' secondimage="https://img.favpng.com/8/6/3/flannel-t-shirt-check-tartan-png-favpng-WTRJ5MaFK2kmEebBrD5QkL6fj.jpg"/>

  <ColumnsGrid all="$2.29" dis='Best Black airport' title="True view" firstimage="https://vmart.pk/wp-content/uploads/2019/04/products-Samsung_Galaxy_Buds_Black_4.jpg"
  all1="$3.29" dis1='Best Quality Handfree' secondimage="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpa_cuIZ5dxvgOmcjakqe4xiDP-qHtCIMJMw&usqp=CAU" />

  
  </div>






  <div style={{display:'flex'}}>

< RowAndColumnSpacing text="Customized Products" text2="Partner with one of 60,000 experienced manufacturers with design & production capabilities and on-time delivery."
img="https://www.pngitem.com/pimgs/m/25-255974_color-pencil-png-transparent-image-transparent-background-colored.png" 
text3='premium OEM Factories' img2='https://s.alicdn.com/@sc04/kf/H06e7c566bcc64ba58332647d62609844H.jpg_q80.jpg'
img3='https://s.alicdn.com/@sc04/kf/H61d3374f236c45d2b78ebfd3341059147.jpg_q80.jpg' img4='https://s.alicdn.com/@sc04/kf/H7afd071e60ac4eb0a3d11da0ae4f57143.jpg_q80.jpg'
 text4='Top-Ranking Suppliers'
 img5='https://s.alicdn.com/@sc04/kf/H81a7ec485b0a4f3da5caa9722b6a5acfD.jpg_q80.jpg'
 img6='https://s.alicdn.com/@sc04/kf/H566727c1875044e3a9b518c02425905eq.jpg_q80.jpg'
 img7='https://s.alicdn.com/@sc04/kf/H6f3f87ae7c1d45319653673680805f02m.jpg_q80.jpg'   />
< RowAndColumnSpacing
  text='Ready-to-ship products'
  text2='Source from 15 million products that are ready to ship, and leave the facility within 15 days.'
  img='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAOEBAQEBAQEhAQEBAOEBAQEA8RDw8PFREWFxgRFRUZHiggGCYoGxUVITEhJSktLi8uGB80OTQtOCgtLi4BCgoKDg0OGhAQGy0lICUtLS0wLi8tLS0tLS0vLy0tLSstLS0vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABQYBAwQHAv/EAD4QAAIBAQMGCgkEAgIDAAAAAAABAgMEBREGEiExUXETM0FSYXKRsbLRFSIyNFOBgpKhQnODohbBI2Ik8PH/xAAbAQEAAgMBAQAAAAAAAAAAAAAABQYCAwQBB//EADsRAAIBAgEIBgcIAgMAAAAAAAABAgMRBAUSITFBUXGxEzJhgZGhFBUzNMHR8CI1UlOCsuHxBhYjctL/2gAMAwEAAhEDEQA/APcQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYMZy2oA+ga+EW1dqHCx5y7UAbAa+Fjzl2ocLHnR7UeXBsBr4WPOXahwsecu1AGwGvhY85dqHCx5y7UAbAa+Fjzl2ocLHnLtQBsBr4WPOXahwkdq7Ueg2A+OEW3uPoAyDCZkAAAAAAAAAAAAAAAAAAApV+XjOpUlHFqEJNKK1Np4YvaRmJut3G1f3J+Jmg+c4ubq1pSnpd3z1FqowUIKMdwABy5kdxtuwZMAZkdwuwABmR3C7AAGZHcLsAAZkdwuwABmR3C7GBus1pnSkpQlmtbNT6GuU0gzi8x3jofZoPJLOVnpL/YK/C04VMMM6KbWxnUR1xP/AMenufiZIn0ihJypRk9bSfkiqVIqM5JbGwADaYAAAAAAAAAAAAAAAHnls4yfXn4maTda+Mn15eJmk+bVvaS4vmWyHVQABqMgAAAAAAAAAAAAAAAAAC75P+7U90vGySIzJ73enul42SZ9FwXu1P8A6x5FWr+1lxfMAA6TUAAAAAAAAAAAAAAAed2rjJ9eXezUbbVxk+vLvZqPmtX2kuL5lsh1UAAazIAAAAAAAAAAAAAAAAAAu2T3u1L6vGxfF6KzxWjOnLHNjyYbWMnvdqX1eNkJlY/+WK2U13sulbEzw+Tac4a82C8UiBp0VVxcoy1XlzNbyitD5YL6TH+RWjavsiRIKx6yxf5kvEl/RaP4F4Et/kNo5y+yJj/IbRtX2RIoD1ji/wAyXiPRaP4V4Ilv8itHOj9iPuGUlZa+Da2ZrWP5IYHqyji/zJeI9Fo/gXgXq7LxhaI4x0SXtReuLO88+sVqlRmpw1rWuRrpLvYbVGtBTjqetcqfKmWrJeUViYZs+utfat6+PyZC4zCOjK66r8uxnUACWOIAAA88tXGT68vEzSbbXxk+vLxM1Hzat7SXFlsh1UAAajIAAAAAAAAAAAAAAAAAAu2T3u1L6vGyEyr46PUXeyayd92p/V4mQmVfHL9td7LZj/uqnwp8kQ2F98n+rmQoAKmTJI3Nd0bRKUZScVGOdow2kx/i9Pnz7EcuSPt1Oou8tRbMk4DDVsLGdSCbu9+8hcZiatOs4xlZaCvvJen8SfYiNvW5JUI58ZOcf1aMHHpLka5wTTTWKawaepo7a2R8LODjGOa9jV9Bzwx9aMk27rcednfc14uzz08XLRNbOlbhfN3uhUwWPByxcHs6HuOAqH/Ng6+6UX9dz5E59jEU96Z6LCSaTTTT0prU0fZV8m7zwaoTevi2+R83yLQXrB4qGJpKpDvW57iu16MqM3F/2AAdRpPO7Xxk+vLxM1G218ZPry8TNR82re0lxZbIdVAAGoyAAAAAAAAAAAAAAAAAALtk77tT+rxsgsquP/jj3sncnfdqf1eNkFlVx/8AHHvZa8f91U+EP2kLhffJ/q5kMACqE0T+SPt1OovEWoquSPt1Oou8tReMh+5R4vmyvZQ9u+C5AAEscRyW+yRr03CXLpT5Yy5GijWmzypTlCSwcXhv6UeiELlBdvDQz4L/AJILR/2WwhcsZP8ASKfSQ68fNbuK2eB34HFdFLNlqfkyop4af/qLncd4cPT0v14aJdOyRTDsui18DVjL9LeE9z/9x+RXslY30esrv7MtD+D7uVyUxuH6Wn2rV8u8veIMaNqBe9BW9B59bOMn15+Jmk3W3janXn4maT5rW9pLi+ZbYdVAAGsyAAAAAAAAAAAAAAAAAALtk77tT+rxsgsquP8A4497J3J33an9XjZBZVcf/HHvZa8f91U+EP2kNhffJ/q5kMACqEyS+Ttsp0ZTdSWanBJPBvF49BP+nLN8T+svIpIJbC5XrYakqcIxsr677e9HHWwMKs8+Tf13F29OWb4n9ZeQ9OWb4n9ZeRSQb/8AYMR+GPg/mavVdLe/L5F19O2b4n9ZeQd/Wb4n9ZeRSgP9gxOyMfB/+h6spb35fI67zlTdWUqTxhLTqawb1rScrMAha1TpJSna17vRq0khTjmpR3Fhxe1mT5BbCukLbeNqdefiZpN9v42r15+Jmgqlb2kuL5lhh1UAAazIAAAA+lFvUm9wlBrWsN6aPe0XPkGTB4AAAAAAAAAC7ZO+7U/q8bILKrj/AOOPeydyd92p/V42QWVXH/xx72WvH/dVPhD9pDYX3yf6uZDAAqhMgA+km9Sx3aQD5B9ypyWuMlvTR8Hr0BaQADwAAHjPVrLAAC4FaIa38bV/cn4maDfb+Nq/uT8TNBVKvtJcWWKGoAG2y2eVWcYR1yeHQulmMYuTSWtnraSuzZYbFOvLNgt7eqK2tlosNw0aaTks+XK37PyidtgscKEFCO9vlk9rNd4XlToL1ni3qitbLhhMmUMJT6SvZy2t6l2L563s0EFXxdSvLMp6uzWzrhTUdCSS2JJH1KKetYlSr5SVpP1YqC3Zz7X5GKOUdaL9bMkulYPtRs9e4RPNTduGjw1+Rj6urWvo8SdtlzUaqfq5sudHBPs1Mq953bOzv1tMX7M1qfQ9jLPdt707Ro9mfNfLufKdtejGpFwksYvWjzE4DDY6n0lKyexrk/jtQpYmrh55s723P4HnoOu9LE6FRxelfpe1HIU6rSlSm4TVmtBPQmppSjqYABrMgAAC65Pe7U90vGyDyq4/+OPeT1we7Ut0vGyByq4/+OPeWzKKtkumuyHIhcJ73P8AVzIc2WazzqyUILGT/C2vYfEIOTSSxbaSW1su11XfGhDDXJ6Zy2vZuIXJuT5Yub2RWt/Bdr8jvxeKVCPa9S+JyXfk9Tgk6nry2foXy5fmS9OlGKwilFdCSNVstkKEc6bwXIuWT2JFdtOUk2/UiorkctMvJFolWwWT0oqye5K77382Q6p18U76/JfXAtbOC13VRqp50Entjof41lep5RWhPTmS6HHDuJm7b9hWajJZk3qTeKk+hmNPKeDxb6OW3ZJaH43V/Pcezwlej9teTIG9rmnQ9ZetT52GmO9f7Iw9FnBNNNYprBp6mimX3dvAVNHFz0x6HyohcrZKVBdLS6u1bv45cNUhgsa6jzJ6+ZGgAgGSa1lgABcCtEXetmlSqzUlreMXtxeOKOM9AtNmp1VhOKklp08m40ehrP8ACXbLzObEZAqTqSlCas3fTe+ngjupZTgoJSTv2WKMWTJOy+3Vf7ce9vuJN3LZvhL7p+Z1WWzQpRzYRzY68MW9L3m3J+RqmHrqpUaaWq19fh9M14rHwq03CCenkYttoVKnKb1RWOG18i7SiWmvKrJzk8ZS07uhFpyqlhQS21Ip/bJ/6KicmX68nWjS2JX73/BvyZSSpue1u3cAAV8kzMJOLTTaaeKa1pl3ua28PSUn7S9WXWKQWHI+WmsuTCD+ekmch4iUMSqeyV0+5Np+XmcGUaSlSztqO3Kiy59HPWum8fpeh/6fyKgeiVaanFxksYyTTW1M4vQlm+Gvun5ktlPJE8TVVSm0tGm99nBbjiwmOjRhmSTenYUgF39CWf4a+6fmPQlm+Gvun5kd/r2I/FHz+R1etKW5+XzKQZSbaS0t6Elrb2F29CWb4S+6fmbqF30aemFOKe3DF9rMo/49Wb+1ONu9/BHksqU7aIvy+Yu2i6dGnB61HT0PWQeVVklnRrLTHBQl/wBWnof5LQfE4prBrFPQ0+UsOKwca+H6G9tCs+Gr+SLo15U6vSePeVPJazZ9Vza0U1o3vQvxiWqpNRTk3goptvYkfFmslOlnZkVHOeLw2nJf882zVMOVJfJySNOFoeg4Rp2bSk32v+reBnWqek1lsTsip3jbZV6jnLVqjHYthygFHqVJVJOcndvSyxxioqy1AyYBgZFxydt7rU3GTxnTwTfOT1P8YG++rKqtGaw0pZy3rT5r5kBktNqvhySg0/lgy3NYl4ybU9KwVqmnXF9v82K5i4dDXvDsZ5yZp05TajFYyk8ElrZdlc9n+FH+3mbrNYqVN4wpxi9WKWnDeREP8dq3WfNW22vfuud0sqQt9mLv9dpH+i6m1dpgm8AWX0anufj/AARPSyMgA6DWAAARWUVndShLDXBqp8lr/DZSz0hrEqF9XLKm3Omsab04LXDo3Fay7gZzarwV9Fn8H8HuJbJ2JjFOnLu+RDAyYKtdEyC05J2dqE6j/W0lujjp7X+CGuq6p2hp4ONPHTN8q2LaXShSUIqMVhGKSS6Cx5DwM+k9ImrJau1vRfhbnoInKOJjm9FHXt7Pp2NoALWQwAAAAAAAAAOK9aDq0akFrcdG9aV3HaYZjOCnFxepq3iexk4tNbDzjAwWG/rmli6tJYp6ZQWtPalylfPnmLwk8LUzJ9z2Ph9aC0Ua8a0c6P8AX15mADru676lolhFaP1TeqPnuNNOnKpJQgrt7EZzkoLOk7IlMk6GM51OSMcxb28e5fktKOexWaNGChHUuXlb5WzpL/gML6NQjTevW+LK1ia3TVHMAA7DQAAAAAAAAADGBkAHDWuujN4ypQb2pZre/AxSumzxeKpRx6cZd53g0+j0r52Yr8EbOlqWtnO3FmEjIBuNYAAAAAAAAAAAAAABg5LTYKVTTOnFvbhg+1aTsBjKEZq0lddunmeptO6ZHRuazp4qlH5uTXY2dtOCikkkktSWhI2AxhShT6kUuCSPZTlLrNsAA2GIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/9k='
  text3='Fatch Dispatch'
  img2='https://s.alicdn.com/@sc04/kf/H0fa28dbc77e74dcabd120a5684e0f08f9.jpg_q80.jpg'
  img3='https://s.alicdn.com/@sc04/kf/HTB1ciM3XBGw3KVjSZFwq6zQ2FXaT.jpg_q80.jpg'
  img4='https://s.alicdn.com/@sc04/kf/H172bdbd5f13d485d95b317577124f6f4L.jpg_q80.jpg'
  text4='Weekly Deals'
  img5='https://s.alicdn.com/@sc04/kf/HTB1YHfJbMaH3KVjSZFpq6zhKpXau.jpg_q80.jpg'
  img6='https://s.alicdn.com/@sc04/kf/H8fa7be7d477747399116fe3ae0b523d3s.jpg_q80.jpg'
  img7='https://s.alicdn.com/@sc04/kf/Hf239b0ffb6c54d4083852218b817f25cV.jpg_q80.jpg'

/>
</div>

<div>

<Bigcard2 />

</div>

<div>

  <Bigcard />

</div>

<div>
  <Bigcard3 />

</div>

<div>

  <Allcard />

</div>

<Foo />

  </div>
  );
}

export default App;
